package Dervis;

public class Alphabets {

        public static void main(String args[])
        {
            char t;

            for (t = 'a'; t <= 'z'; t++) // For upper case use 'A' and 'Z'
                System.out.println(t);
        }
    }
